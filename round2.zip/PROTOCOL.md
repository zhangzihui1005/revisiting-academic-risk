# Round 2 sensitivity protocol • 26 November 2026

This protocol was specified in response to the second review, after the v5.0 target results had been examined and before fitting the two additional models. All comparisons are exploratory. The v5.0 evidence remains the historical reference (Zenodo version DOI 10.5281/zenodo.24215762).

## Training contrast

For the nine-domain 2013 reference policy and the three-domain 2013B calendar proxy, refit the original flat, unweighted 16-feature CatBoost model on every Day-28-eligible source enrollment. Keep the v5.0 feature order, class order, seed, iterations, learning rate, depth, regularization and other implementation settings. Exclude all students on the raw 2014 roster before forming source membership. Sort the expanded source by enrollment key, as in v5.0. No new model selection, calibration or Day 56 fit. Score all eligible target records at Day 28. Reuse the original common-training Day 28 and Day 56 scores. The change measures sensitivity to training membership under the previously selected configuration.

## Outputs and inference

1. On the original Day 28/56 target intersection, compare Withdrawal nAP in reference 2014B, reference 2014J and proxy 2014B. The proxy 2014J reuses the reference 2014J fit and targets. Distinguish the original gain (frozen Day 56 minus original Day 28), the sensitivity gain (same Day 56 minus expanded-training Day 28), and the change in gain (sensitivity minus original). A negative change indicates that including historical early leavers reduces the temporal gain. Retain all three settings regardless of direction.
2. Use 2,000 paired student-cluster bootstrap draws per setting, v5.0 seed 20261114, sorted unique student IDs and shared resampling weights across the three prediction vectors. Recalculate prevalence and nAP per draw. Report empirical 2.5th and 97.5th percentiles. Uncertainty is conditional on the fitted models. The settings share data and do not supply independent replications.
3. On the entire dynamic Day 28 target of each presentation, report original/expanded-training Withdrawal nAP, alert count at the original top-10% enrollment capacity (ceiling, score descending and enrollment key ascending), and the number/fraction of withdrawals in (28, 56] captured. Day-28 rankings are computed before restricting to early withdrawals. These are descriptive coverage measures.
4. Tabulate existing dynamic Fail and Withdrawal LR3/LR16 nAP, paired differences and archived intervals. Tabulate seven held-out modules' historical withdrawal Platt diagnostic slopes and the existing equal-module Platt-minus-intercept Brier and log-loss contrasts. These are extracts of v5.0 results, with no additional fitting or resampling.

## Verification

Verify frozen inputs against the versioned source index, compare the original common training IDs and the shared predictions/target membership against the archive, reproduce the original withdrawal bootstrap series and screening counts, and check selected resamples against independently computed sklearn average precision. Record models, parameters, source/test membership, predictions, bootstrap draws, RNG state, software versions and checksums. The restored rows must pass the original landmark rules and feature cutoffs. Report any discrepancy with these checks.
