# Early-withdrawal training sensitivity

This extension contains the full Day 28 historical risk-set refits, paired temporal contrasts and screening coverage. The reference and calendar-proxy models retain their source-selected configurations. All three settings reuse previously examined targets. Training and testing use public OULAD pseudonymous IDs under the data license. The modified Figure 2 uses the original four-landmark trajectories.

From the repository root, restore the underlying frozen features and historical predictions with `python reviewer.py restore --workdir _reviewer`. Extract round2.zip into round2/. Install the root requirements-lock.txt in Python 3.12. The following commands refit the two Day 28 models and independently replay the bootstrap draws:

```sh
python -B round2/run_round2.py --archive _reviewer --out round2_replay
python -B round2/verify_round2.py --archive _reviewer --results round2_replay
python round2/figure2/draw_figure2.py
```

The distributed results/ directory includes full-precision S36, S45A and S45B tables, archived calibration extracts, membership records, model configurations, per-enrollment predictions, 2,000 matched student-cluster replicates per setting, and checksums of the v5.0 inputs. The two 2014B settings share the same targets. Only one 2014J policy is scored. See PROTOCOL.md and results/audit/independent_replay.json for definitions and numerical verification.
