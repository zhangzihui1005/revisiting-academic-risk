"""Reproduce the Round 2 withdrawal sensitivity from the extracted Zenodo v5.0 reviewer archive."""
import argparse
from datetime import datetime, timezone
from importlib.metadata import version
import hashlib
import json
import os
from pathlib import Path
import platform
import sys

sys.dont_write_bytecode = True
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--archive", required=True, type=Path, help="Directory containing inputs/, fullrisk/, code/, tables/ and SOURCE_INDEX.json")
parser.add_argument("--out", required=True, type=Path, help="New results directory")
args = parser.parse_args()
archive, out = args.archive.resolve(), args.out.resolve()
if out == archive or archive in out.parents or out in archive.parents:
    parser.error("Keep new results separate from the archive.")
out.mkdir(parents=True, exist_ok=False)
index = json.loads((archive / "SOURCE_INDEX.json").read_text(encoding="utf8"))
sources = {}


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def source(name):
    path = archive / name
    actual = digest(path)
    assert actual == index[name]["sha256"], name
    sources[name] = actual
    return path


source("code/common.py")
source("code/fullrisk.py")
source("requirements-lock.txt")
sys.path.insert(0, str(archive / "code"))
os.environ["ACADEMIC_RISK_REVISION_ROOT"] = str(archive)
import common as v5
import numpy as np
import pandas as pd
from catboost import CatBoostClassifier
from sklearn.metrics import average_precision_score
from threadpoolctl import threadpool_limits

SEED = 20261114
DRAWS = 2000
KEY = ["record_id", "id_student"]
POLS = {"retrospective_all2013": {"2014B": "reference_2014B", "2014J": "reference_2014J"},
        "proxy_2013B": {"2014B": "proxy_2014B"}}


def load(name):
    return v5.read(source(name))


def save(name, data):
    v5.savecsv(pd.DataFrame(data), out / name)


def near(a, b):
    np.testing.assert_allclose(a, b, atol=2e-13, rtol=0)


def nap(y, p, w=None):
    prevalence = np.average(y, weights=w)
    return (average_precision_score(y, p, sample_weight=w) - prevalence) / (1 - prevalence)


def align(original, new, on):
    result = original.merge(new, on=on, validate="one_to_one", how="outer", indicator=True)
    assert result["_merge"].eq("both").all()
    return result.drop(columns="_merge")


def paired(setting, z, original_result):
    prefix = f"fullrisk/paired/{setting}_CatBoost16_Withdrawal/"
    archived = load(prefix + "paired_predictions.csv")
    on_common = z.loc[z.p56.notna()].sort_values("record_id")
    p = align(archived, on_common[KEY + ["y", "p28_old", "p28_new", "p56"]],
              KEY + ["y"]).sort_values("record_id").reset_index(drop=True)
    near(p.p_a, p.p28_old)
    near(p.p_b, p.p56)
    y = p.y.to_numpy(int)
    scores = p[["p28_old", "p28_new", "p56"]].to_numpy().T
    funcs = [v5.WeightedAP(y, s) for s in scores]
    ids, inverse = np.unique(p.id_student, return_inverse=True)
    np.testing.assert_array_equal(ids, load(prefix + "cluster_order.csv").id_student)
    rng = np.random.default_rng(SEED)
    initial = rng.bit_generator.state
    estimates = np.array([nap(y, s) for s in scores])
    boot = np.empty((DRAWS, 3))
    for i in range(DRAWS):
        w = np.bincount(rng.integers(len(ids), size=len(ids)), minlength=len(ids))[inverse]
        boot[i] = [fn(w) for fn in funcs]
        if i in (0, 1, 997, DRAWS - 1):
            near(boot[i], [nap(y, s, w) for s in scores])
    rng_record = {"initial": initial, "final": rng.bit_generator.state}
    assert rng_record == json.loads(source(prefix + "rng_state.json").read_text())
    v5.dump(out / f"audit/{setting}_rng.json", rng_record)
    old, new, later = boot.T
    values = np.column_stack((later - old, later - new, old - new))
    near(values[:, 1] - values[:, 0], values[:, 2])
    draws = load(prefix + "draws.csv")
    np.testing.assert_array_equal(draws.draw_id, np.arange(DRAWS))
    near(boot[:, 0], draws.nAP_a)
    near(boot[:, 2], draws.nAP_b)
    near(values[:, 0], draws.delta_nAP)
    assert np.isfinite(boot).all()
    valid = np.isfinite(values).all(axis=1)
    assert valid.all()
    b = pd.DataFrame(boot, columns=["nAP28_common_train", "nAP28_full_train", "nAP56_frozen"])
    b[["original_gain", "revised_gain", "change_in_gain"]] = values
    b.insert(0, "draw_id", np.arange(DRAWS))
    save(f"bootstrap/{setting}.csv", b)
    save(f"bootstrap/{setting}_cluster_order.csv", {"id_student": ids})
    a, n, h = estimates
    result = dict(setting=setting, N=len(y), students=len(ids), withdrawals=int(y.sum()),
                  nAP28_common_train=a, nAP28_full_train=n, nAP56_frozen=h,
                  original_gain=h-a, revised_gain=h-n, change_in_gain=a-n)
    for j, col in enumerate(("original_gain", "revised_gain", "change_in_gain")):
        result[col + "_lo"], result[col + "_hi"] = np.quantile(values[valid, j], [.025, .975])
    near([a, h, h-a, result["original_gain_lo"], result["original_gain_hi"]],
         original_result[["nAP_a", "nAP_b", "delta_nAP", "CI95_low", "CI95_high"]].to_numpy(float))
    result.update(draws=DRAWS, valid=int(valid.sum()), seed=SEED)
    return result


def dynamic(setting, z, waiting, capacity):
    early = z.y.eq(1) & z.date_unregistration.between(28, 56, inclusive="right")
    assert (early == z.p56.isna()).all()
    k = int(np.ceil(0.10 * len(z)))
    result = dict(setting=setting, N=len(z), students=z.id_student.nunique(), withdrawals=z.y.sum(),
                  early_withdrawals=early.sum(), alerts=k)
    near([len(z), z.p56.notna().sum(), early.sum()], waiting[["day28_N","common_N","withdrawn_between28_56"]].to_numpy(float))
    for label, col in (("common_train", "p28_old"), ("full_train", "p28_new")):
        order = np.lexsort((z.record_id.to_numpy(str), -z[col].to_numpy()))
        alert = np.zeros(len(z), dtype=bool)
        alert[order[:k]] = True
        z["alert_" + label] = alert
        hits = int(early[alert].sum())
        result.update({f"nAP_{label}": nap(z.y, z[col]), f"early_hits_{label}": hits,
                       f"early_recall_{label}": hits/int(early.sum()),
                       f"withdrawal_hits_{label}": int(z.y[alert].sum())})
    near(result["nAP_common_train"],capacity.nAP)
    assert result["early_hits_common_train"] == waiting.between_withdrawals_captured_by_D28_top10
    assert result["withdrawal_hits_common_train"] == capacity.captured_events and k == capacity.alerts
    result["delta_dynamic_nAP"] = result["nAP_full_train"] - result["nAP_common_train"]
    result["delta_early_hits"] = result["early_hits_full_train"] - result["early_hits_common_train"]
    z["withdrawn_in_28_56"] = early
    return result


def make_existing(capacity):
    contrasts = load("tables/representation_contrasts.csv").copy()
    for arm, field in (("LR3","nAP_a"), ("LR16","nAP_b")):
        ref = capacity.loc[capacity.arm.eq(arm) & capacity.unit.eq("enrollment")]
        cols = ["setting", "horizon", "task"]
        vals = contrasts.merge(ref[cols + ["nAP", "N"]], on=cols, validate="one_to_one")
        assert len(vals) == len(contrasts) == 12 and (vals.N_x == vals.N_y).all()
        near(vals[field], vals.nAP)
    near(contrasts.nAP_b-contrasts.nAP_a, contrasts.delta_nAP)
    save("tables/S36_LR_absolute_and_paired.csv", contrasts.rename(columns={"nAP_a":"LR3_nAP","nAP_b":"LR16_nAP"}))
    diagnostics = load("tables/calibration_domain_diagnostics.csv")
    wd = diagnostics.loc[diagnostics.experiment.str.startswith("A_withdrawal_")]
    slopes = wd.loc[wd.method.eq("platt"), ["experiment","method","N","events","prevalence","CITL","intercept","slope","status"]]
    assert len(slopes) == 7 and slopes.slope.notna().all()
    save("tables/withdrawal_target_slopes.csv", slopes)
    contrasts = load("tables/calibration_global_contrasts.csv")
    res = []
    for metric in ("Brier", "LogLoss"):
        row = contrasts.loc[contrasts.task.eq("withdrawal") & contrasts.contrast.eq("equal7_platt_minus_intercept_"+metric)].iloc[0].to_dict()
        for label in ("platt","intercept"):
            part = wd.loc[wd.method.eq(label)]
            assert len(part) == 7 and part.N.sum() == row["N"]
            row[label + "_equal_module_loss"] = part[metric].mean()
        near(row["platt_equal_module_loss"]-row["intercept_equal_module_loss"],row["estimate"])
        res.append(row)
    save("tables/equal_module_calibration.csv", res)


def main():
    started = datetime.now(timezone.utc).isoformat()
    script = Path(__file__).resolve()
    lock = {"started_utc": started, "protocol_sha256": digest(script.with_name("PROTOCOL.md")),
            "script_sha256": digest(script), "seed": SEED, "draws": DRAWS, "policies": POLS,
            "python": platform.python_version(), "platform": platform.platform(),
            "packages": {p:version(p) for p in ("catboost","scikit-learn","numpy","pandas","scipy","threadpoolctl")}}
    v5.dump(out / "audit/execution_lock.json", lock)
    d28, d56 = (load(f"inputs/day{d}.csv") for d in [28,56])
    roster = load("inputs/raw_student_roster.csv")
    forbidden = set(roster.loc[roster.code_presentation.str.startswith("2014"), "id_student"])
    assert d28.record_id.is_unique and d56.record_id.is_unique
    temporal = load("tables/fullrisk_temporal_contrasts.csv")
    waiting = load("tables/waiting_time_coverage.csv")
    capacity = load("tables/fullrisk_capacity_metrics.csv")
    make_existing(capacity)
    audit, pairs, cover = [], [], []
    for policy, settings in POLS.items():
        files = f"fullrisk/{policy}/CatBoost16/"
        spec = json.loads(source(files + "selection_LOCKED.json").read_text())
        assert spec["seed"] == SEED and spec["features"] == v5.FEATURES and spec["policy"] == policy
        train = d28.loc[d28.domain.isin(spec["source_domains"]) & ~d28.id_student.isin(forbidden)].sort_values("record_id")
        assert train.code_presentation.str.startswith("2013").all() and not set(train.id_student)&forbidden
        common = train.loc[train.record_id.isin(d56.record_id)]
        archived = load(files + "common_training_records.csv")
        align(common[KEY + ["y_three"]], archived[KEY + ["y_three"]], KEY + ["y_three"])
        assert v5.kh(common.record_id) == spec["train_key_hash"] and len(common) == spec["train_N"]
        extra = train.loc[~train.record_id.isin(common.record_id)]
        assert extra.y_three.eq(2).all() and extra.date_unregistration.between(28,56,inclusive="right").all()
        members = train[KEY + ["domain","y_three","date_unregistration"]].copy()
        members["in_common_training"] = members.record_id.isin(common.record_id)
        save(f"membership/{policy}.csv", members)
        audit.append(dict(policy=policy, domains=len(spec["source_domains"]), original_N=len(common),
                          expanded_N=len(train), added_N=len(extra), added_early_withdrawals=len(extra),
                          original_students=common.id_student.nunique(), expanded_students=train.id_student.nunique(),
                          original_withdrawals=common.y_three.eq(2).sum(), expanded_withdrawals=train.y_three.eq(2).sum(),
                          raw_target_student_overlap=0, common_key_hash=v5.kh(common.record_id), full_key_hash=v5.kh(train.record_id)))
        model = v5.model("CatBoost16", spec["params"])
        with threadpool_limits(limits=6):
            model.fit(train[spec["features"]], train.y_three)
        model_path = out / f"models/{policy}.cbm"
        model_path.parent.mkdir(parents=True,exist_ok=True)
        model.save_model(str(model_path))
        v5.dump(out / f"models/{policy}_config.json", {"original_selection":spec,"actual_parameters":model.get_all_params(),
                "classes":list(model.classes_), "feature_names":model.feature_names_, "model_sha256":digest(model_path)})
        target28 = d28.loc[d28.code_presentation.isin(settings)]
        target56 = d56.loc[d56.code_presentation.isin(settings)]
        assert not set(target28.id_student)&set(train.id_student)
        p = v5.proba(model, target28, spec["features"])
        reloaded = CatBoostClassifier().load_model(str(model_path))
        near(p, v5.proba(reloaded, target28, spec["features"]))
        new = v5.predict_frame(target28, p)
        save(f"predictions/{policy}_D28_all_classes.csv", new)
        old28, old56 = (load(files + f"D{h}_predictions.csv") for h in (28,56))
        fields = KEY + ["y_three","domain","code_presentation"]
        combined = align(new[fields+["date_unregistration","p_Withdrawal"]], old28[fields+["p_Withdrawal"]].rename(columns={"p_Withdrawal":"p28_old"}), fields)
        combined.rename(columns={"p_Withdrawal":"p28_new"},inplace=True)
        align(target56[fields],old56[fields],fields)
        for presentation, setting in settings.items():
            z = combined.loc[combined.code_presentation.eq(presentation)].merge(old56[fields+["p_Withdrawal"]].rename(columns={"p_Withdrawal":"p56"}),on=fields,how="left",validate="one_to_one").sort_values("record_id").reset_index(drop=True)
            z["y"] = z.y_three.eq(2).astype(int)
            original = temporal.loc[temporal.setting.eq(setting)&temporal.arm.eq("CatBoost16")&temporal.task.eq("Withdrawal")].iloc[0]
            pair = paired(setting,z,original)
            pairs.append(pair)
            wait = waiting.loc[waiting.setting.eq(setting)&waiting.arm.eq("CatBoost16")].iloc[0]
            cap = capacity.loc[capacity.setting.eq(setting)&capacity.arm.eq("CatBoost16")&capacity.task.eq("Withdrawal")&capacity.horizon.eq(28)&capacity.unit.eq("enrollment")].iloc[0]
            cover.append(dynamic(setting,z,wait,cap))
            save(f"predictions/{setting}_withdrawal.csv",z)
            print(setting, "original, sensitivity, change", pair["original_gain"],pair["revised_gain"],pair["change_in_gain"],flush=True)
    save("tables/source_membership_audit.csv",audit)
    save("tables/S45A_common_target_gains.csv",pairs)
    save("tables/S45B_dynamic_day28.csv",cover)
    assert all(digest(archive / n) == h for n,h in sources.items())
    v5.dump(out / "audit/v5_read_sources_sha256.json", sources)
    v5.dump(out / "audit/validation.json", dict(status="PASS",finished_utc=datetime.now(timezone.utc).isoformat(),
        new_day28_fits=2, new_searches=0, new_day56_fits=0, unique_settings=len(pairs),
        retained_sources_checked_before_and_after=len(sources), valid_draws_per_setting=[r["valid"] for r in pairs],
        original_draw_series_replayed=True, cluster_orders_and_final_rng_match=True, published_original_intervals_reproduced=True,
        independent_sklearn_draw_checks_per_setting=4, new_model_save_reload_verified=True, old_dynamic_counts_and_nAP_reproduced=True,
        source_membership_equal_to_frozen_intersection=True, source_student_overlap_with_raw_2014=0,
        baseline_absolute_metrics_crosschecked=True, equal_module_loss_differences_reconstructed=True,
        archive_doi="10.5281/zenodo.24215762",interval="pointwise paired student-cluster percentile, fixed fits"))


if __name__ == "__main__":
    main()
