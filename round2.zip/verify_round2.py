"""Independent replay using physically repeated enrollment rows and sklearn AP."""
import argparse
import hashlib
import json
from pathlib import Path
import sys
import numpy as np
import pandas as pd
from sklearn.metrics import average_precision_score

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--archive", type=Path, required=True)
parser.add_argument("--results", type=Path, required=True)
args = parser.parse_args()
archive, results = args.archive.resolve(), args.results.resolve()
assert not (results == archive or archive in results.parents or results in archive.parents)
assert sys.flags.optimize == 0, "Run with Python assertions enabled."


def read(p):
    return pd.read_csv(p, float_precision="round_trip")


def digest(p):
    with p.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def close(actual, expected):
    np.testing.assert_allclose(actual, expected, atol=2e-13, rtol=0)


source_index = json.loads((archive / "SOURCE_INDEX.json").read_text())
cutoff_file = "audit/raw_feature_reconstruction.csv"
assert digest(archive / cutoff_file) == source_index[cutoff_file]["sha256"]
cutoff = read(archive / cutoff_file)
assert (cutoff.day.tolist() == [28,56] and cutoff.retained_log_max_day.equals(cutoff.day)
        and (cutoff.max_feature_difference == 0).all())
summary = read(results / "tables/S45A_common_target_gains.csv").set_index("setting")
coverage = read(results / "tables/S45B_dynamic_day28.csv").set_index("setting")
h28, h56 = (read(archive / f"inputs/day{h}.csv").set_index("record_id") for h in [28,56])
checks = []
for setting, row in summary.iterrows():
    dynamic = read(results / f"predictions/{setting}_withdrawal.csv").set_index("record_id").sort_index()
    pres = setting.split("_")[1]
    ids28 = h28.index[h28.code_presentation.eq(pres)]
    ids56 = h56.index[h56.code_presentation.eq(pres)]
    assert set(dynamic.index) == set(ids28)
    common = dynamic.loc[sorted(set(ids28)&set(ids56))]
    assert len(common) == row.N and dynamic.loc[common.index,"p56"].notna().all()
    early = h28.loc[ids28]
    early_ids = set(early.index[(early.final_result=="Withdrawn") & (early.date_unregistration>28) & (early.date_unregistration<=56)])
    cap = coverage.loc[setting]
    assert len(early_ids) == cap.early_withdrawals
    for col, label in (("p28_old","common_train"),("p28_new","full_train")):
        top = dynamic.reset_index().sort_values([col,"record_id"],ascending=[False,True]).iloc[:int(cap.alerts)]
        assert len(set(top.record_id)&early_ids) == cap["early_hits_"+label]
        assert set(top.record_id) == set(dynamic.index[dynamic["alert_"+label]])
    y = (h28.loc[common.index,"final_result"]=="Withdrawn").to_numpy(int)
    assert (y == common.y).all()
    ids, group = np.unique(h28.loc[common.index,"id_student"], return_inverse=True)
    assert len(ids) == row.students
    p = common[["p28_old","p28_new","p56"]].to_numpy()
    archived = read(results / f"bootstrap/{setting}.csv")
    rng = np.random.default_rng(int(row.seed))
    fresh = np.empty((len(archived),3))
    for i in range(len(archived)):
        pick = rng.choice(len(ids), size=len(ids), replace=True)
        repetitions = np.bincount(pick,minlength=len(ids))[group]
        indices = np.repeat(np.arange(len(common)),repetitions)
        yy = y[indices]
        pi = yy.mean()
        for j in range(3):
            fresh[i,j] = (average_precision_score(yy,p[indices,j])-pi)/(1-pi)
    expected = archived[["nAP28_common_train","nAP28_full_train","nAP56_frozen"]].to_numpy()
    close(fresh,expected)
    quantities = np.column_stack([fresh[:,2]-fresh[:,0],fresh[:,2]-fresh[:,1],fresh[:,0]-fresh[:,1]])
    for j,name in enumerate(("original_gain","revised_gain","change_in_gain")):
        close(np.quantile(quantities[:,j],[0.025,0.975]), [row[name+"_lo"],row[name+"_hi"]])
    checks.append(dict(setting=setting,paired_draws=len(fresh),max_abs_nAP_error=float(np.max(np.abs(fresh-expected))),
                       dynamic_early_alert_lists_reproduced=True,all_three_paired_intervals_reproduced=True))
    print(setting,checks[-1],flush=True)
record = dict(status="PASS",method="sklearn AP on physically repeated enrollment rows per sampled student",
              checks=checks,frozen_cutoff_audit_sha256=digest(archive/cutoff_file),
              verified_v5_retained_VLE_max_days=[28,56],
              source_note="Uses the archived raw-feature reconstruction audit. No new raw feature reconstruction.")
(results/"audit/independent_replay.json").write_text(json.dumps(record,indent=2)+"\n",encoding="utf8")
