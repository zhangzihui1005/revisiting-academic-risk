"""Draw Figure 2 from the frozen S13 source values using the Figure 3–5 styles."""
import csv
from pathlib import Path
from xml.etree import ElementTree as ET

here=Path(__file__).resolve().parent
records=list(csv.DictReader((here/"Figure_02_data.csv").open(encoding="utf8")))
svg=ET.Element("svg",{"xmlns":"http://www.w3.org/2000/svg","width":"180mm","height":"82.8mm","viewBox":"0 0 1000 460"})
def el(tag,**k):
    return ET.SubElement(svg,tag,{key.replace("_","-"):str(v) for key,v in k.items()})
def label(x,y,s,size=19,anchor="start",bold=False):
    el("text",x=x,y=y,font_family="Arial, sans-serif",font_size=size,text_anchor=anchor,font_weight="700" if bold else "400",fill="#202b33").text=s
def line(x1,y1,x2,y2,color,width=1,**extra):
    el("line",x1=x1,y1=y1,x2=x2,y2=y2,stroke=color,stroke_width=width,**extra)
def series(points,name):
    color="#26728d" if name=="dynamic" else "#ae6931"
    kw={} if name=="dynamic" else {"stroke_dasharray":"9 5"}
    el("polyline",points=" ".join(f"{x:.3f},{y:.3f}" for x,y in points),fill="none",stroke=color,stroke_width=3,**kw)
    for x,y in points:
        if name=="dynamic":el("circle",cx=x,cy=y,r=6,fill=color)
        else:el("rect",x=x-4,y=y-4,width=8,height=8,fill="white",stroke=color,stroke_width=2)
el("rect",width=1000,height=460,fill="white")
for i,(task,title,lo,hi,ticks) in enumerate([("failure","a  Conditional failure",.25,.60,[.30,.40,.50,.60]),("withdrawal","b  Future withdrawal",.04,.14,[.04,.06,.08,.10,.12,.14])]):
    left=82+491*i; right=left+372; top=99; bottom=343
    y=lambda v: bottom-(v-lo)/(hi-lo)*(bottom-top)
    x=lambda day: left+10+(day-14)/70*(right-left-20)
    label(left-46,37,title,25,bold=True);label(left-46,78,"nAP",19)
    for tick in ticks:
        line(left,y(tick),right,y(tick),"#e7ecef");label(left-12,y(tick)+6,f"{tick:.2f}",18,"end")
    line(left,bottom,right,bottom,"#44535b",1.6)
    for day in [14,28,56,84]:label(x(day),373,str(day),19,"middle")
    label((left+right)/2,405,"Landmark day",20,"middle")
    for name in ["dynamic","common"]:
        part=sorted((r for r in records if r["cohort"]==name and r["task"]==task),key=lambda r:int(r["day"]))
        assert [int(r["day"]) for r in part]==[14,28,56,84]
        series([(x(int(r["day"])),y(float(r["nAP"]))) for r in part],name)
for x,name,text in [(275,"dynamic","Dynamic risk set"),(535,"common","Common cohort")]:
    color="#26728d" if name=="dynamic" else "#ae6931"
    line(x,438,x+51,438,color,3,**({"stroke_dasharray":"9 5"} if name=="common" else {}))
    series([(x+25,438)],name);label(x+62,445,text,20)
ET.ElementTree(svg).write(here/"Figure_02.svg",encoding="utf-8",xml_declaration=True)
